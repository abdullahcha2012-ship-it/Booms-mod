package com.example.auction;

import net.minecraft.world.item.Item;

public final class AuctionState {
    public static final AuctionState I = new AuctionState();

    public enum Phase { IDLE, RUNNING, SOLD, UNSOLD }

    // ---- auction data ----
    public Phase phase = Phase.IDLE;
    public Item item;
    public int qty = 1;
    public double minBid = 1;
    public double worthTotal;
    public long endAt, resultUntil;
    public String topBidder = "-";
    public double topBid = 0;
    public int bids = 0;

    // ---- settings: colors ----
    public static final int BORDER = 0, BG = 1, TITLE = 2, TEXT = 3, WINNER = 4, PAID = 5, COUNT = 6, PUP = 7, PDOWN = 8, TOP = 9;
    public static final String[] NAMES = {"Border", "Background", "Title", "Text", "Winner", "Paid", "Countdown", "Profit +", "Profit -", "Top bidder"};
    public static final int[] DEFAULT_COLORS = {0xFFFF8A00, 0xD0050014, 0xFFFFAA00, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFF5555, 0xFF55FF55, 0xFFFF5555, 0xFFBBBBBB};
    public final int[] c = DEFAULT_COLORS.clone();

    // ---- settings: layout (0 = HUD box, 1 = countdown, 2 = sold line) ----
    // HUD: ox/oy are the top-left in screen pixels. Countdown and sold: offsets from the screen center.
    public static final String[] ELEMENTS = {"HUD box", "Countdown number", "Sold line"};
    public final int[] ox = {6, 0, 0};
    public final int[] oy = {40, 0, 0};
    public final float[] scale = {1f, 1f, 1f};

    public void setColor(int i, int rgb) {
        c[i] = (i == BG ? 0xD0000000 : 0xFF000000) | (rgb & 0xFFFFFF);
        save();
    }
    public void resetColors() { System.arraycopy(DEFAULT_COLORS, 0, c, 0, c.length); save(); }
    public void resetLayout() {
        ox[0] = 6; oy[0] = 40; ox[1] = ox[2] = oy[1] = oy[2] = 0;
        scale[0] = scale[1] = scale[2] = 1f; save();
    }

    private static java.nio.file.Path file() {
        return net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("booms-mod.properties");
    }
    public void save() {
        try {
            java.util.Properties p = new java.util.Properties();
            for (int i = 0; i < c.length; i++) p.setProperty("c" + i, Integer.toString(c[i]));
            for (int i = 0; i < 3; i++) {
                p.setProperty("ox" + i, Integer.toString(ox[i])); p.setProperty("oy" + i, Integer.toString(oy[i]));
                p.setProperty("s" + i, Float.toString(scale[i]));
            }
            try (var o = java.nio.file.Files.newOutputStream(file())) { p.store(o, "Booms Mod"); }
        } catch (Exception ignored) {}
    }
    public void load() {
        try {
            if (!java.nio.file.Files.exists(file())) return;
            java.util.Properties p = new java.util.Properties();
            try (var in = java.nio.file.Files.newInputStream(file())) { p.load(in); }
            for (int i = 0; i < c.length; i++) c[i] = Integer.parseInt(p.getProperty("c" + i, "" + c[i]));
            for (int i = 0; i < 3; i++) {
                ox[i] = Integer.parseInt(p.getProperty("ox" + i, "" + ox[i])); oy[i] = Integer.parseInt(p.getProperty("oy" + i, "" + oy[i]));
                scale[i] = Float.parseFloat(p.getProperty("s" + i, "" + scale[i]));
            }
        } catch (Exception ignored) {}
    }

    // ---- auction logic ----
    public void start(Item item, int qty, double minBid, double worthPerUnit, int seconds) {
        this.item = item; this.qty = qty; this.minBid = minBid;
        this.worthTotal = worthPerUnit * qty;
        this.endAt = System.currentTimeMillis() + seconds * 1000L;
        topBidder = "-"; topBid = 0; bids = 0;
        phase = Phase.RUNNING;
    }
    public void cancel() { phase = Phase.IDLE; }

    public void onPayment(String who, double amount) {
        if (phase != Phase.RUNNING || amount < minBid) return;
        bids++;
        if (amount > topBid) { topBid = amount; topBidder = who; }
    }

    private int fwTick = -1;
    private static void play(net.minecraft.sounds.SoundEvent e, float pitch) {
        net.minecraft.client.Minecraft.getInstance().getSoundManager()
                .play(net.minecraft.client.resources.sounds.SimpleSoundInstance.forUI(e, pitch, 1.0f));
    }
    private void fireworks() {
        if (fwTick < 0) return;
        switch (fwTick) {
            case 0 -> play(net.minecraft.sounds.SoundEvents.FIREWORK_ROCKET_LAUNCH, 1.0f);
            case 8 -> { play(net.minecraft.sounds.SoundEvents.FIREWORK_ROCKET_BLAST, 1.0f); play(net.minecraft.sounds.SoundEvents.FIREWORK_ROCKET_TWINKLE, 1.0f); }
            case 14 -> play(net.minecraft.sounds.SoundEvents.FIREWORK_ROCKET_LAUNCH, 1.2f);
            case 22 -> { play(net.minecraft.sounds.SoundEvents.FIREWORK_ROCKET_BLAST, 1.2f); play(net.minecraft.sounds.SoundEvents.FIREWORK_ROCKET_TWINKLE, 1.2f); }
            case 30 -> play(net.minecraft.sounds.SoundEvents.FIREWORK_ROCKET_BLAST, 0.9f);
            default -> {}
        }
        if (++fwTick > 40) fwTick = -1;
    }

    public void tick() {
        long now = System.currentTimeMillis();
        fireworks();
        if (phase == Phase.RUNNING && now >= endAt) {
            phase = bids > 0 ? Phase.SOLD : Phase.UNSOLD;
            resultUntil = now + 5000;
            if (phase == Phase.SOLD) fwTick = 0;
        } else if ((phase == Phase.SOLD || phase == Phase.UNSOLD) && now >= resultUntil) {
            phase = Phase.IDLE;
        }
    }

    public double secondsLeft() { return Math.max(0, (endAt - System.currentTimeMillis()) / 1000.0); }
    public double profit() { return topBid - worthTotal; }
}

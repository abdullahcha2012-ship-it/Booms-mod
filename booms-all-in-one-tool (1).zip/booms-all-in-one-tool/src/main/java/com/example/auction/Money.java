package com.example.auction;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class Money {
    private static final Pattern P = Pattern.compile("^([\\d,]*\\.?\\d+)\\s*([KkMmBbTt]?)$");
    private static final String[] S = {"", "K", "M", "B", "T"};

    /** "700M" -> 7.0E8, "1.9B" -> 1.9E9, returns -1 if invalid. */
    public static double parse(String s) {
        Matcher m = P.matcher(s.trim().replace("$", ""));
        if (!m.matches()) return -1;
        double v = Double.parseDouble(m.group(1).replace(",", ""));
        return switch (m.group(2).toUpperCase()) {
            case "K" -> v * 1e3; case "M" -> v * 1e6;
            case "B" -> v * 1e9; case "T" -> v * 1e12;
            default -> v;
        };
    }

    public static String fmt(double v) {
        boolean neg = v < 0; v = Math.abs(v);
        int i = 0;
        while (v >= 1000 && i < S.length - 1) { v /= 1000; i++; }
        String n = (v == Math.floor(v)) ? String.valueOf((long) v)
                 : String.format("%.2f", v).replaceAll("0+$", "").replaceAll("\\.$", "");
        return (neg ? "-" : "") + "$" + n + S[i];
    }
}

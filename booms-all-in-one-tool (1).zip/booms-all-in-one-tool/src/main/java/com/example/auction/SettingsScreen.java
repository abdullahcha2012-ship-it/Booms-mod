package com.example.auction;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/** Two tabs: Colors (wheel, brightness, hex, 10 targets) and Layout (move + size for 3 elements). */
public class SettingsScreen extends Screen {
    private static final int PW = 300, PH = 236, R = 44;

    private final Screen parent;
    private int tab;            // 0 = colors, 1 = layout
    private int target = 0;
    private int moving = -1;    // element being moved, -1 = none
    private int px, py, cx, cy, barX, barY;
    private float h, sat, val = 1f;
    private boolean dragWheel, dragBar, updatingHex;
    private EditBox hex;

    public SettingsScreen(Screen parent, int tab) {
        super(Component.literal("Settings"));
        this.parent = parent; this.tab = tab;
    }

    @Override
    protected void init() {
        px = (width - PW) / 2; py = (height - PH) / 2;
        cx = px + 58; cy = py + 82; barX = cx + R + 12; barY = cy - R;

        addRenderableWidget(Button.builder(Component.literal("Colors"), b -> { tab = 0; rebuildWidgets(); })
                .bounds(px + 8, py + 6, 60, 16).build());
        addRenderableWidget(Button.builder(Component.literal("Layout"), b -> { tab = 1; rebuildWidgets(); })
                .bounds(px + 72, py + 6, 60, 16).build());
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(px + PW - 58, py + PH - 24, 50, 16).build());

        if (tab == 0) initColors(); else initLayout();
    }

    // ------------------------------------------------------------------ colors tab
    private void initColors() {
        for (int i = 0; i < AuctionState.NAMES.length; i++) {
            final int idx = i;
            addRenderableWidget(Button.builder(Component.literal(AuctionState.NAMES[i]), b -> { target = idx; loadTarget(); })
                    .bounds(px + 166 + (i % 2) * 66, py + 28 + (i / 2) * 16, 64, 14).build());
        }
        hex = addRenderableWidget(new EditBox(font, px + 206, py + 124, 60, 16, Component.literal("Hex")));
        hex.setMaxLength(6);
        hex.setResponder(t -> {
            if (updatingHex || t.length() != 6) return;
            try {
                int rgb = Integer.parseInt(t, 16);
                AuctionState.I.setColor(target, rgb);
                float[] hsv = rgbToHsv(rgb);
                h = hsv[0]; sat = hsv[1]; val = hsv[2];
            } catch (NumberFormatException ignored) {}
        });
        addRenderableWidget(Button.builder(Component.literal("Reset colors"), b -> { AuctionState.I.resetColors(); loadTarget(); })
                .bounds(px + PW - 142, py + PH - 24, 80, 16).build());
        loadTarget();
    }

    private void loadTarget() {
        int rgb = AuctionState.I.c[target] & 0xFFFFFF;
        float[] hsv = rgbToHsv(rgb);
        h = hsv[0]; sat = hsv[1]; val = hsv[2];
        setHex(rgb);
    }
    private void setHex(int rgb) {
        updatingHex = true; hex.setValue(String.format("%06X", rgb & 0xFFFFFF)); updatingHex = false;
    }
    private void applyColor() {
        int rgb = hsvToRgb(h, sat, val);
        AuctionState.I.setColor(target, rgb);
        setHex(rgb);
    }
    private void pickWheel(double mx, double my) {
        double dx = mx - cx, dy = my - cy, d = Math.min(Math.sqrt(dx * dx + dy * dy), R);
        h = (float) ((Math.atan2(dy, dx) / (2 * Math.PI) + 1) % 1);
        sat = (float) (d / R);
        applyColor();
    }
    private void pickBar(double my) {
        val = (float) Math.max(0, Math.min(1, 1 - (my - barY) / (2.0 * R)));
        applyColor();
    }

    // ------------------------------------------------------------------ layout tab
    private static final class ScaleSlider extends AbstractSliderButton {
        private final int idx;
        ScaleSlider(int x, int y, int w, int h, int idx) {
            super(x, y, w, h, Component.empty(), (AuctionState.I.scale[idx] - 0.5) / 2.0);
            this.idx = idx; updateMessage();
        }
        @Override protected void updateMessage() {
            setMessage(Component.literal("Size " + Math.round(AuctionState.I.scale[idx] * 100) + "%"));
        }
        @Override protected void applyValue() {
            AuctionState.I.scale[idx] = (float) (0.5 + value * 2.0);   // 50% .. 250%
            AuctionState.I.save();
        }
    }

    private void initLayout() {
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            int y = py + 48 + i * 48;
            addRenderableWidget(Button.builder(Component.literal("Move"), b -> moving = idx)
                    .bounds(px + 8, y + 14, 50, 16).build());
            addRenderableWidget(new ScaleSlider(px + 64, y + 14, 150, 16, idx));
        }
        addRenderableWidget(Button.builder(Component.literal("Reset layout"), b -> { AuctionState.I.resetLayout(); rebuildWidgets(); })
                .bounds(px + PW - 142, py + PH - 24, 80, 16).build());
    }

    // ------------------------------------------------------------------ input
    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        AuctionState s = AuctionState.I;
        if (moving >= 0) {
            if (moving == 0) {
                s.ox[0] = (int) e.x() - (int) (AuctionHud.W * s.scale[0] / 2);
                s.oy[0] = (int) e.y() - (int) (AuctionHud.H * s.scale[0] / 2);
            } else {
                s.ox[moving] = (int) e.x() - width / 2;
                s.oy[moving] = (int) e.y() - height / 2;
            }
            s.save(); moving = -1;
            return true;
        }
        if (tab == 0) {
            double dx = e.x() - cx, dy = e.y() - cy;
            if (dx * dx + dy * dy <= (R + 3) * (R + 3)) { dragWheel = true; pickWheel(e.x(), e.y()); return true; }
            if (e.x() >= barX && e.x() <= barX + 12 && e.y() >= barY && e.y() <= barY + 2 * R) { dragBar = true; pickBar(e.y()); return true; }
        }
        return super.mouseClicked(e, dbl);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent e, double dx, double dy) {
        if (dragWheel) { pickWheel(e.x(), e.y()); return true; }
        if (dragBar) { pickBar(e.y()); return true; }
        return super.mouseDragged(e, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent e) {
        dragWheel = dragBar = false;
        return super.mouseReleased(e);
    }

    @Override
    public void onClose() {
        AuctionState.I.save();
        minecraft.setScreenAndShow(parent);
    }

    // ------------------------------------------------------------------ drawing
    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float pt) {
        AuctionState s = AuctionState.I;

        if (moving >= 0) {   // full-screen preview, click to place
            AuctionHud.drawSamples(g);
            g.text(font, "Click where you want the " + AuctionState.ELEMENTS[moving] + " (centered on your click)", 6, 6, 0xFFFFFF55);
            return;
        }

        g.fill(px, py, px + PW, py + PH, s.c[AuctionState.BORDER]);
        g.fill(px + 1, py + 1, px + PW - 1, py + PH - 1, 0xF0100010);

        if (tab == 0) drawColors(g); else drawLayoutLabels(g);
        super.extractRenderState(g, mx, my, pt);
    }

    private void drawLayoutLabels(GuiGraphicsExtractor g) {
        AuctionState s = AuctionState.I;
        for (int i = 0; i < 3; i++) {
            int y = py + 48 + i * 48;
            g.text(font, AuctionState.ELEMENTS[i], px + 8, y, s.c[AuctionState.TITLE]);
            g.text(font, "Move: click a spot. Size: 50% to 250%.", px + 8, y + 34, 0xFF888888);
        }
    }

    private void drawColors(GuiGraphicsExtractor g) {
        AuctionState s = AuctionState.I;
        // wheel
        int cell = 3;
        for (int yy = -R; yy < R; yy += cell) {
            for (int xx = -R; xx < R; xx += cell) {
                double ccx = xx + cell / 2.0, ccy = yy + cell / 2.0, d = Math.sqrt(ccx * ccx + ccy * ccy);
                if (d > R) continue;
                float hh = (float) ((Math.atan2(ccy, ccx) / (2 * Math.PI) + 1) % 1);
                g.fill(cx + xx, cy + yy, cx + xx + cell, cy + yy + cell, 0xFF000000 | hsvToRgb(hh, (float) (d / R), val));
            }
        }
        int mkx = cx + (int) (Math.cos(h * 2 * Math.PI) * sat * R), mky = cy + (int) (Math.sin(h * 2 * Math.PI) * sat * R);
        g.fill(mkx - 3, mky - 3, mkx + 4, mky + 4, 0xFF000000);
        g.fill(mkx - 2, mky - 2, mkx + 3, mky + 3, 0xFFFFFFFF);
        // brightness bar
        for (int i = 0; i < 2 * R; i += 2)
            g.fill(barX, barY + i, barX + 12, barY + i + 2, 0xFF000000 | hsvToRgb(h, sat, 1f - i / (2f * R)));
        int by = barY + (int) ((1 - val) * 2 * R);
        g.fill(barX - 2, by - 1, barX + 14, by + 2, 0xFFFFFFFF);

        // edit row
        g.text(font, "Edit: " + AuctionState.NAMES[target], px + 166, py + 112, 0xFFFFFFFF);
        g.fill(px + 166, py + 124, px + 190, py + 140, 0xFFFFFFFF);
        g.fill(px + 167, py + 125, px + 189, py + 139, 0xFF000000 | hsvToRgb(h, sat, val));
        g.text(font, "#", px + 196, py + 128, 0xFFFFFFFF);

        // live previews
        g.text(font, "Preview", px + 8, py + 134, 0xFFBBBBBB);
        g.pose().pushMatrix();
        g.pose().translate(px + 8, py + 146);
        g.pose().scale(0.8f, 0.8f);
        g.fill(0, 0, AuctionHud.W, AuctionHud.H, s.c[AuctionState.BORDER]);
        g.fill(1, 1, AuctionHud.W - 1, AuctionHud.H - 1, s.c[AuctionState.BG]);
        g.text(font, "Booms All In One Tool", AuctionHud.W / 2 - font.width("Booms All In One Tool") / 2, 5, s.c[AuctionState.TITLE]);
        g.text(font, "3x Elytra", 6, 33, s.c[AuctionState.TEXT]);
        g.text(font, "0:10", AuctionHud.W - 30, 33, s.c[AuctionState.TEXT]);
        g.text(font, "Top: zeno $2B", 6, 44, s.c[AuctionState.TOP]);
        g.text(font, "Worth  $2.1B", 6, 54, s.c[AuctionState.TEXT]);
        g.text(font, "Profit  $300M", 6, 64, s.c[AuctionState.PUP]);
        g.text(font, "Bids 6", AuctionHud.W - 38, 64, s.c[AuctionState.TEXT]);
        g.pose().popMatrix();
        g.pose().pushMatrix();
        g.pose().translate(px + 200, py + 162);
        g.pose().scale(2f, 2f);
        g.text(font, "10", -font.width("10") / 2, 0, s.c[AuctionState.COUNT]);
        g.pose().popMatrix();
        AuctionHud.soldLine(g, px + 232, py + 198, 1f, 14, "zeno", " paid $2B");
    }

    // ------------------------------------------------------------------ color math
    static int hsvToRgb(float h, float s, float v) {
        float c = v * s, x = c * (1 - Math.abs((h * 6) % 2 - 1)), m = v - c, r, gr, b;
        switch ((int) (h * 6) % 6) {
            case 0 -> { r = c; gr = x; b = 0; } case 1 -> { r = x; gr = c; b = 0; }
            case 2 -> { r = 0; gr = c; b = x; } case 3 -> { r = 0; gr = x; b = c; }
            case 4 -> { r = x; gr = 0; b = c; } default -> { r = c; gr = 0; b = x; }
        }
        return (Math.round((r + m) * 255) << 16) | (Math.round((gr + m) * 255) << 8) | Math.round((b + m) * 255);
    }
    static float[] rgbToHsv(int rgb) {
        float r = ((rgb >> 16) & 255) / 255f, g = ((rgb >> 8) & 255) / 255f, b = (rgb & 255) / 255f;
        float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b)), d = max - min, hh = 0;
        if (d > 0) {
            if (max == r) hh = ((g - b) / d) % 6; else if (max == g) hh = (b - r) / d + 2; else hh = (r - g) / d + 4;
            hh /= 6; if (hh < 0) hh += 1;
        }
        return new float[]{hh, max == 0 ? 0 : d / max, max};
    }
}

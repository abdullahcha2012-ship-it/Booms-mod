package com.example.auction;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AuctionMod implements ClientModInitializer {
    // Matches DonutSMP-style "Name paid you $1.9B"
    private static final Pattern PAID = Pattern.compile("(\\w{1,16}) paid you \\$([\\d,.]+[KkMmBbTt]?)");

    private static KeyMapping openKey;

    @Override
    public void onInitializeClient() {
        AuctionState.I.load();
        openKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.auction.open", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_R,
                KeyMapping.Category.register(Identifier.fromNamespaceAndPath("auction", "main"))));

        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            Matcher m = PAID.matcher(message.getString());
            if (m.find()) {
                double amt = Money.parse(m.group(2));
                if (amt > 0) AuctionState.I.onPayment(m.group(1), amt);
            }
        });

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            AuctionState.I.tick();
            while (openKey.consumeClick()) {
                if (mc.screen == null) mc.setScreenAndShow(new AuctionScreen());
            }
        });

        HudElementRegistry.attachElementAfter(VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath("auction", "hud"),
                (graphics, delta) -> AuctionHud.render(graphics));
    }
}

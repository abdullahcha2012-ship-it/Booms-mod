package com.example.auction;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public final class AuctionHud {
    public static final int W = 140, H = 78;
    private static final Identifier DONUT = Identifier.fromNamespaceAndPath("auction", "textures/gui/donut.png");

    public static void render(GuiGraphicsExtractor g) {
        AuctionState s = AuctionState.I;
        if (s.phase == AuctionState.Phase.IDLE) return;
        ItemStack st = new ItemStack(s.item == null ? Items.ELYTRA : s.item);
        double p = s.profit();
        boolean up = p >= 0 && s.bids > 0;
        hud(g, s.ox[0], s.oy[0], s.scale[0], st, s.qty + "x " + st.getHoverName().getString(),
                s.phase == AuctionState.Phase.RUNNING ? String.format("0:%02d", (int) Math.ceil(s.secondsLeft())) : "",
                "Top: " + s.topBidder + " " + (s.topBid > 0 ? Money.fmt(s.topBid) : ""),
                "Worth  " + Money.fmt(s.worthTotal), "Profit  " + (s.bids == 0 ? "-" : Money.fmt(p)),
                s.c[up ? AuctionState.PUP : AuctionState.PDOWN], "Bids " + s.bids);

        int cx = g.guiWidth() / 2, cy = g.guiHeight() / 2;
        if (s.phase == AuctionState.Phase.RUNNING) {
            int left = (int) Math.ceil(s.secondsLeft());
            if (left >= 1 && left <= 10) countdown(g, String.valueOf(left), left <= 3 ? 5f : 4f);
        } else if (s.phase == AuctionState.Phase.SOLD) {
            sold(g, s.topBidder, " paid " + Money.fmt(s.topBid));
        } else if (s.phase == AuctionState.Phase.UNSOLD) {
            countdown(g, "NO BIDS", 3f);
        }
    }

    /** Sample of all three elements, used while moving things in the settings. */
    public static void drawSamples(GuiGraphicsExtractor g) {
        AuctionState s = AuctionState.I;
        ItemStack st = new ItemStack(Items.ELYTRA);
        hud(g, s.ox[0], s.oy[0], s.scale[0], st, "3x Elytra", "0:10", "Top: zeno $2B", "Worth  $2.1B", "Profit  -$100M",
                s.c[AuctionState.PDOWN], "Bids 6");
        countdown(g, "10", 4f);
        sold(g, "zeno", " paid $2B");
    }

    private static void hud(GuiGraphicsExtractor g, int x, int y, float sc, ItemStack stack, String qtyItem,
                            String time, String top, String worth, String profit, int profitColor, String bids) {
        AuctionState s = AuctionState.I;
        Font f = Minecraft.getInstance().font;
        g.pose().pushMatrix();
        g.pose().translate(x, y);
        g.pose().scale(sc, sc);
        g.fill(0, 0, W, H, s.c[AuctionState.BORDER]);
        g.fill(1, 1, W - 1, H - 1, s.c[AuctionState.BG]);
        String title = "Booms All In One Tool";
        g.text(f, title, W / 2 - f.width(title) / 2, 5, s.c[AuctionState.TITLE]);
        g.item(stack, W / 2 - 8, 15);
        g.text(f, qtyItem, 6, 33, s.c[AuctionState.TEXT]);
        g.text(f, time, W - 30, 33, s.c[AuctionState.TEXT]);
        g.text(f, top, 6, 44, s.c[AuctionState.TOP]);
        g.text(f, worth, 6, 54, s.c[AuctionState.TEXT]);
        g.text(f, profit, 6, 64, profitColor);
        g.text(f, bids, W - 38, 64, s.c[AuctionState.TEXT]);
        g.pose().popMatrix();
    }

    private static void countdown(GuiGraphicsExtractor g, String text, float base) {
        AuctionState s = AuctionState.I;
        Font f = Minecraft.getInstance().font;
        float sc = base * s.scale[1];
        float cx = g.guiWidth() / 2f + s.ox[1], cy = g.guiHeight() / 2f + s.oy[1];
        g.pose().pushMatrix();
        g.pose().translate(cx, cy - 4.5f * sc);
        g.pose().scale(sc, sc);
        g.text(f, text, -f.width(text) / 2, 0, s.c[AuctionState.COUNT]);
        g.pose().popMatrix();
    }

    private static void sold(GuiGraphicsExtractor g, String name, String rest) {
        AuctionState s = AuctionState.I;
        soldLine(g, g.guiWidth() / 2 + s.ox[2], g.guiHeight() / 2 + s.oy[2], 1.5f * s.scale[2], Math.round(20 * s.scale[2]), name, rest);
    }

    /** Logo + "Name paid $X" centered on cx, cy. Also used for the small preview in the settings. */
    static void soldLine(GuiGraphicsExtractor g, int cx, int cy, float sc, int icon, String name, String rest) {
        AuctionState s = AuctionState.I;
        Font f = Minecraft.getInstance().font;
        int gap = 4;
        float textW = (f.width(name) + f.width(rest)) * sc;
        float startX = cx - (icon + gap + textW) / 2f;
        g.blit(net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED, DONUT,
                (int) startX, cy - icon / 2, 0f, 0f, icon, icon, 64, 64);
        g.pose().pushMatrix();
        g.pose().translate(startX + icon + gap, cy - 4f * sc);
        g.pose().scale(sc, sc);
        g.text(f, name, 0, 0, s.c[AuctionState.WINNER]);
        g.text(f, rest, f.width(name), 0, s.c[AuctionState.PAID]);
        g.pose().popMatrix();
    }
}

package com.example.auction;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

public class AuctionScreen extends Screen {
    private static final int PW = 280, PH = 176;
    private static Item selected = Items.ELYTRA;
    private static int seconds = 30;
    private static String qtyStr = "1", minStr = "1", worthStr = "700M";

    private EditBox search, qty, min, worth;
    private final List<Button> results = new ArrayList<>();
    private final List<Button> timeBtns = new ArrayList<>();
    private int px, py;

    public AuctionScreen() { super(Component.literal("Booms All In One Tool")); }

    @Override
    protected void init() {
        px = (width - PW) / 2; py = (height - PH) / 2;
        int x = px + 8, y = py + 8;

        search = addRenderableWidget(new EditBox(font, x, y, PW - 16, 16, Component.literal("Search items...")));
        search.setHint(Component.literal("Search items..."));
        search.setResponder(t -> refreshResults());

        qty = addRenderableWidget(new EditBox(font, x + 28, y + 80, 40, 16, Component.literal("Qty")));
        qty.setValue(qtyStr);
        min = addRenderableWidget(new EditBox(font, x + 108, y + 80, 60, 16, Component.literal("Min")));
        min.setValue(minStr);
        worth = addRenderableWidget(new EditBox(font, x + 208, y + 80, 56, 16, Component.literal("Worth")));
        worth.setValue(worthStr);

        timeBtns.clear();
        int[] times = {15, 30, 45, 60};
        for (int i = 0; i < 4; i++) {
            final int t = times[i];
            Button b = addRenderableWidget(Button.builder(Component.literal(t + "s"), bt -> { seconds = t; }).bounds(x + 28 + i * 54, y + 100, 50, 16).build());
            timeBtns.add(b);
        }

        addRenderableWidget(Button.builder(Component.literal("Layout"), b -> minecraft.setScreenAndShow(new SettingsScreen(this, 1)))
                .bounds(x, y + 124, 70, 16).build());
        addRenderableWidget(Button.builder(Component.literal("Cancel"), b -> { AuctionState.I.cancel(); onClose(); })
                .bounds(x + 74, y + 124, 50, 16).build());
        addRenderableWidget(Button.builder(Component.literal("Start Auction"), b -> start())
                .bounds(x + 128, y + 124, PW - 16 - 128, 16).build());

        addRenderableWidget(Button.builder(Component.literal("Colors"), b -> minecraft.setScreenAndShow(new SettingsScreen(this, 0)))
                .bounds(x, y + 144, PW - 16, 16).build());

        setInitialFocus(search);
        refreshResults();
    }

    private void refreshResults() {
        results.forEach(this::removeWidget);
        results.clear();
        String q = search.getValue().toLowerCase().trim();
        int shown = 0;
        for (Item it : BuiltInRegistries.ITEM) {
            if (it == Items.AIR) continue;
            String name = new ItemStack(it).getHoverName().getString();
            if (!q.isEmpty() && !name.toLowerCase().contains(q)) continue;
            if (q.isEmpty() && it != Items.ELYTRA && it != Items.NETHERITE_INGOT && it != Items.DIAMOND_BLOCK) continue;
            final Item fi = it;
            Button b = Button.builder(Component.literal(name), bt -> selected = fi)
                    .bounds(px + 8 + (shown % 3) * 88, py + 28 + (shown / 3) * 18, 86, 16).build();
            results.add(addRenderableWidget(b));
            if (++shown >= 6) break;
        }
    }

    private void start() {
        try {
            int q = Math.max(1, Integer.parseInt(qty.getValue().trim()));
            double mn = Money.parse(min.getValue()), w = Money.parse(worth.getValue());
            if (mn < 0 || w < 0) return;
            qtyStr = qty.getValue(); minStr = min.getValue(); worthStr = worth.getValue();
            AuctionState.I.start(selected, q, mn, w, seconds);
            onClose();
        } catch (NumberFormatException ignored) {}
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partial) {
        g.fill(px, py, px + PW, py + PH, AuctionState.I.c[AuctionState.BORDER]);
        g.fill(px + 1, py + 1, px + PW - 1, py + PH - 1, 0xF0100010);
        super.extractRenderState(g, mouseX, mouseY, partial);

        int x = px + 8, y = py + 8;
        g.item(new ItemStack(selected), x, y + 62);
        g.text(font, new ItemStack(selected).getHoverName().getString() + "  " + worth.getValue(), x + 20, y + 66, 0xFFFFAA00);
        g.text(font, "Qty", x, y + 84, 0xFFFFFFFF);
        g.text(font, "Min", x + 84, y + 84, 0xFFFFFFFF);
        g.text(font, "Worth", x + 172, y + 84, 0xFFFFFFFF);
        g.text(font, "Time", x, y + 104, 0xFFFFFFFF);
        // highlight selected time
        int i = seconds / 15 - 1;
        if (i >= 0 && i < 4) g.fill(x + 28 + i * 54, y + 117, x + 78 + i * 54, y + 119, 0xFFFFAA00);

        double q = 1; try { q = Integer.parseInt(qty.getValue().trim()); } catch (Exception ignored) {}
        double w = Money.parse(worth.getValue());
        if (w >= 0) g.text(font, "x" + (int) q + " = " + Money.fmt(w * q), x + 172, y + 104, 0xFF55FF55);

    }
}
